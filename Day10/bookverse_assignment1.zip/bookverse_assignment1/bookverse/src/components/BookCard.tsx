// src/components/BookCard.tsx
import React from "react";

type BookCardProps = {
  title: string;
  author: string;
  price: number;
  viewMode: "grid" | "list";
};

const BookCard: React.FC<BookCardProps> = ({ title, author, price, viewMode }) => {
  return (
    <div
      style={{
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "10px",
        margin: "8px",
        width: viewMode === "grid" ? "180px" : "100%",
        display: "flex",
        flexDirection: viewMode === "grid" ? "column" : "row",
        justifyContent: "space-between",
      }}
    >
      <div>
        <h3>{title}</h3>
        <p>by {author}</p>
      </div>
      <strong>${price.toFixed(2)}</strong>
    </div>
  );
};

export default BookCard;
