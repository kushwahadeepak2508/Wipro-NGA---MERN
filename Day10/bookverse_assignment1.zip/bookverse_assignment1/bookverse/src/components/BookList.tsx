// src/components/BookList.tsx
import React, { useState } from "react";
import BookCard from "./BookCard";

type Book = {
  id: number;
  title: string;
  author: string;
  price: number;
};

const BookList: React.FC = () => {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [search, setSearch] = useState("");

  const books: Book[] = [
    { id: 1, title: "The Great Gatsby", author: "F. Scott Fitzgerald", price: 9.99 },
    { id: 2, title: "1984", author: "George Orwell", price: 8.5 },
    { id: 3, title: "To Kill a Mockingbird", author: "Harper Lee", price: 10.0 },
    { id: 4, title: "The Hobbit", author: "J.R.R. Tolkien", price: 12.5 },
  ];

  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ padding: "20px" }}>
      <h1>📖 Featured Books</h1>

      {/* Controlled Search Box */}
      <input
        type="text"
        placeholder="Search by title..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ padding: "6px", marginBottom: "10px", width: "200px" }}
      />

      {/* Toggle Buttons */}
      <div style={{ marginBottom: "10px" }}>
        <button onClick={() => setViewMode("grid")}>Grid View</button>
        <button onClick={() => setViewMode("list")} style={{ marginLeft: "5px" }}>
          List View
        </button>
      </div>

      {/* Render Books */}
      <div
        style={{
          display: "flex",
          flexDirection: viewMode === "grid" ? "row" : "column",
          flexWrap: "wrap",
        }}
      >
        {filteredBooks.map((book) => (
          <BookCard key={book.id} {...book} viewMode={viewMode} />
        ))}
      </div>
    </div>
  );
};

export default BookList;
