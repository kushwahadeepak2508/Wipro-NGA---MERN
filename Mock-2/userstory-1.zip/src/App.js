import React from 'react';
import Header from './components/Header';
import DestinationCard from './components/DestinationCard';
import Footer from './components/Footer';

import parisImg from './images/paris.jpg';
import baliImg from './images/bali.jpg';
import newyorkImg from './images/newyork.jpg';

function App() {
  const destinations = [
    { name: 'Paris, France', image: parisImg, price: 899 },
    { name: 'Bali, Indonesia', image: baliImg, price: 499 },
    { name: 'New York, USA', image: newyorkImg, price: 699 },
  ];

  return (
    <div>
      <Header />
      <div className="container mt-4">
        <h2 className="text-center mb-4">Featured Destinations</h2>
        <div className="row">
          {destinations.map((dest, index) => (
            <DestinationCard
              key={index}
              name={dest.name}
              image={dest.image}
              price={dest.price}
            />
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default App;
