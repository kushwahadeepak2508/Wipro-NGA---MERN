import React from "react";
import ProductList from "./features/products/ProductList";

export default function App() {
  return (
    <div style={{ padding: 40 }}>
      <ProductList />
    </div>
  );
}
