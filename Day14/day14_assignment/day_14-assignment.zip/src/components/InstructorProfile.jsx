export default function InstructorProfile() {
  return (
    <div style={{ padding: 10 }}>
      <h3>Instructor Profile</h3>
      <p>Name: Jane Doe</p>
      <p>Expertise: React, Performance</p>
    </div>
  );
}
