export default function CourseDetails() {
  return (
    <div style={{ padding: 10 }}>
      <h3>Course Details</h3>
      <p>This component was lazy-loaded.</p>
    </div>
  );
}
